Following resources were used while completing this project:

www.stackoverflow.com
https://github.com/rstudio/rstudio/issues/2656
http://www.sthda.com/english/wiki/qplot-quick-plot-with-ggplot2-r-software-and-data-visualization#histogram-and-density-plots


In order to better analyze the quality of wines we created a rating variable wineData$rating

